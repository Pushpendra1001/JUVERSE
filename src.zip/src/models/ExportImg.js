import blockchain from '../images/blockchain.jpg';
import defi from '../images/defi.jpg';
import nft from '../images/nft.jpg';
import web3 from '../images/web3.jpg';
import water from '../images/water.jpg';


export const images = {
    blockchain,
    defi,
    nft,
    web3,
    water
};